package ua.alarmguard

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Api {
    private const val URL_ALERTS = "https://neptun.in.ua/api/v1/alerts"

    enum class Status { NO_ALERT, ALERT, ERROR }

    data class Result(val status: Status, val message: String)

    fun checkKyiv(): Result {
        return try {
            val conn = (URL(URL_ALERTS).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 8000
                readTimeout = 8000
                useCaches = true
                setRequestProperty("Accept", "application/json")
                setRequestProperty("User-Agent", "AlarmGuard/1.0")
            }
            val code = conn.responseCode
            if (code !in 200..299) return Result(Status.ERROR, "HTTP $code")
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            val json = JSONObject(body)

            val oblasts = json.optJSONArray("oblasts")
            var cityAlert = false
            if (oblasts != null) {
                for (i in 0 until oblasts.length()) {
                    val o = oblasts.optJSONObject(i) ?: continue
                    val key = o.optString("key").lowercase()
                    val name = o.optString("name").lowercase()
                    val oblast = o.optString("oblast").lowercase()
                    if (key == "kyiv" || key == "kyiv-city" ||
                        name == "м. київ" || name == "київ" ||
                        oblast == "м. київ" || oblast == "місто київ") {
                        cityAlert = true
                        break
                    }
                }
            }

            if (cityAlert) Result(Status.ALERT, "🚨 У Києві є повітряна тривога")
            else Result(Status.NO_ALERT, "✅ У Києві тривоги немає")
        } catch (e: Exception) {
            Result(Status.ERROR, "Не вдалося перевірити: ${e.javaClass.simpleName}")
        }
    }
}
