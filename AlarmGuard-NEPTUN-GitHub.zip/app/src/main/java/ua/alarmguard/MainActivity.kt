package ua.alarmguard

import android.app.AlarmManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("p", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 36, 36, 36)
        }
        val title = TextView(this).apply { text = "Будильник без тривоги"; textSize = 26f }
        val info = TextView(this).apply {
            text = "О  заданий час застосунок перевіряє Київ. Якщо є тривога — відкладає будильник на 1 хвилину і перевіряє знову."
            textSize = 16f
            setPadding(0, 20, 0, 20)
        }
        val time = TimePicker(this).apply {
            setIs24HourView(true)
            hour = prefs.getInt("h", 7)
            minute = prefs.getInt("m", 0)
        }
        val save = Button(this).apply { text = "Зберегти будильник" }
        val test = Button(this).apply { text = "Перевірити Київ зараз" }
        val status = TextView(this).apply { textSize = 16f; setPadding(0, 20, 0, 0) }

        save.setOnClickListener {
            Scheduler.schedule(this, time.hour, time.minute)
            status.text = "Будильник встановлено на %02d:%02d".format(time.hour, time.minute)
        }
        test.setOnClickListener {
            status.text = "Перевіряю…"
            Thread {
                val r = Api.checkKyiv()
                runOnUiThread { status.text = r.message }
            }.start()
        }

        root.addView(title)
        root.addView(info)
        root.addView(time)
        root.addView(save)
        root.addView(test)
        root.addView(status)
        setContentView(root)

        if (android.os.Build.VERSION.SDK_INT >= 31) {
            val am = getSystemService(AlarmManager::class.java)
            if (!am.canScheduleExactAlarms()) {
                startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
            }
        }
    }
}
