package ua.alarmguard

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.PowerManager
import android.os.SystemClock
import java.util.Calendar
import java.util.concurrent.Executors

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val pending = goAsync()
        val lock = (context.getSystemService(Context.POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AlarmGuard:check")
        lock.acquire(15000)

        Executors.newSingleThreadExecutor().execute {
            try {
                val result = Api.checkKyiv()
                when (result.status) {
                    Api.Status.ALERT -> Scheduler.scheduleAfter(context, 60_000L)
                    Api.Status.NO_ALERT -> {
                        AlarmPlayer.start(context)
                        Scheduler.scheduleNextDay(context)
                    }
                    Api.Status.ERROR -> {
                        // On an API error, retry in one minute rather than silently waking.
                        Scheduler.scheduleAfter(context, 60_000L)
                    }
                }
            } finally {
                lock.release()
                pending.finish()
            }
        }
    }
}

object Scheduler {
    private const val REQUEST_CODE = 1001

    fun schedule(context: Context, hour: Int, minute: Int) {
        val prefs = context.getSharedPreferences("p", Context.MODE_PRIVATE)
        prefs.edit().putInt("h", hour).putInt("m", minute).putBoolean("enabled", true).apply()
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        setAt(context, cal.timeInMillis)
    }

    fun scheduleAfter(context: Context, delayMs: Long) {
        setAt(context, System.currentTimeMillis() + delayMs)
    }

    fun scheduleNextDay(context: Context) {
        val p = context.getSharedPreferences("p", Context.MODE_PRIVATE)
        val h = p.getInt("h", 7)
        val m = p.getInt("m", 0)
        val cal = Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, 1)
            set(Calendar.HOUR_OF_DAY, h)
            set(Calendar.MINUTE, m)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        setAt(context, cal.timeInMillis)
    }

    fun restore(context: Context) {
        val p = context.getSharedPreferences("p", Context.MODE_PRIVATE)
        if (p.getBoolean("enabled", false)) schedule(context, p.getInt("h", 7), p.getInt("m", 0))
    }

    private fun setAt(context: Context, millis: Long) {
        val alarm = context.getSystemService(AlarmManager::class.java)
        val intent = Intent(context, AlarmReceiver::class.java)
        val pi = PendingIntent.getBroadcast(
            context, REQUEST_CODE, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, pi)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED) Scheduler.restore(context)
    }
}
